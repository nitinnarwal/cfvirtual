package com.example.nitin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NitinApplicationTests {

	@Test
	void contextLoads() {
	}

}
